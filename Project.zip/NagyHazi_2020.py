
import time
import turtle
import desks
import foods
import extensions

def Start():
    ##ablak
    window = turtle.Screen() 
    window.setup(720, 720)
    window.bgcolor("black")
    window.title("Üdvözlöm!")
    ##kör 
    turtle.speed(0)
    turtle.pensize(7)
    turtle.color("black")
    turtle.penup()        
    turtle.goto(0,-150)        
    turtle.pendown()    
    turtle.color("red")
    turtle.circle(200)
    turtle.penup()
    ##bal oldali J  
    turtle.goto(-90, 50)
    turtle.right(130)    
    turtle.pensize(30)    
    turtle.pendown()
    turtle.forward(50)
    turtle.left(90)
    turtle.forward(50)
    turtle.left(90)
    turtle.forward(200)
    turtle.penup()
    ##jobb oldali R
    turtle.goto(-40,-50)
    turtle.pendown()
    turtle.forward(200)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    time.sleep(2)
    turtle.bye()
    MainMenu()

def MainMenu():
    while True:
        extensions.Clear()
        print("Jaser éttermi szoftver\n")
        print("Asztalok:")
        print("\tAsztal nyitás:           1")
        print("\tAsztalok megjelenítése:  2")
        print("\tAsztalok módosítása:     3")
        print("Menü:")
        print("\tRendelés leadás:         4")        
        print("\tSzámla:                  5")
        print("\tMenü módosítása:         6\n")
        print("Kilépés: e")
        choose = input()
        extensions.Clear()
        if choose == "1":
            desks.Table_opening()
        elif choose == "2":
            desks.Table_drawing()
        elif choose == "3":
            desks.Table_modify()
        elif choose == "4":
            foods.Order()
        elif choose == "5":
            foods.Receipt()
        elif choose == "6":
            foods.Menu_modify()
        elif choose == "e": # Kilépés
            break
        else:
            extensions.Error(4)  # Nem létező opció
Start()