import turtle
import extensions

class Table: # Osztály az asztalok adatainak
    def __init__(self, number, places, reserved, x, y):
        try:
            if type(number) is int and type(places) is int and type(reserved) is str and type(x) is int and type(y) is int:
                self.number = number
                self.places = places
                self.reserved = reserved
                self.x = x
                self.y = y
            else:
                raise ValueError        
        except ValueError:
            extensions.Error(1) # Bemeneti file hiba
    def __str__(self): # Képernyőre való kiírás, szép, szellős, jól érthető módon
            return "Sorszám: {}\tFérőhelyek: {}\tSzabad (s) / foglalt (f): {}\tElhelyezkedés (x, y): {},{}\n".format(self.number, self.places, self.reserved, self.x, self.y)

def Tabsave(tablist): # Külön függvény az asztal típusú elemekből álló lista fájlba írására (pontosvesszővel elválasztott adatok)
    with open("tables.txt", "wt", encoding="utf-8") as a:
        for oneline in tablist:
                if oneline != "":
                    a.write("{};{};{};{};{}\n".format(oneline.number, oneline.places, oneline.reserved, oneline.x, oneline.y))

def TableOpener(): # Az asztalokat tartalmazó fájl beolvasása
    tablelist = []
    try:
        with open("tables.txt", "rt", encoding="utf-8") as b:
            for oneline in b:
                oneline = oneline.strip() # Leszedünk egy sort
                if oneline != "":
                    parts = oneline.split(";") # Szétbonzótjuk pontosvesszőnként
                    try:
                        tablelist.append(Table(int(parts[0]), int(parts[1]), parts[2], int(parts[3]), int(parts[4]))) # Majd Asztal osztálybbeli elem részeiként beleírjuk egy listába
                    except ValueError:
                        extensions.Error(1) # Bemeneti file hiba
        return tablelist
    except FileNotFoundError:
        extensions.Error(2)

def Exisingtables(item): # Külön kis függvény, kap egy sorszámot, visszatér True-val, ha van ilyen sorszámmal asztal, False-al, ha nincs
    lis = TableOpener()
    for a in lis:
        if item == a.number:
            return True
    return False

def Table_opening(): # Aszal foglalás
    templist = TableOpener()  # Eltárolja az asztalokat
    notreservable = [] # A nem foglalható asztalok listája
    print("Asztalnyitás\nMelyik asztalt kívánja lefoglalni?")
    try:
        for a in templist:        
            if a.reserved == "s":
                print("Asztal száma: {} Helyeinek száma: {}".format(str(a.number), str(a.places))) # Ha szabad az asztal, kiírja a sorszámát és a férőhelyek számát
            elif a.reserved == "f":
                notreservable.append(a.number) # Különben a nem foglalhatókhoz rakja
            else:
                raise ImportError
        if len(notreservable) == len(templist): # Ha minden asztal foglalt
            print("Nincs foglalható asztal!")
            extensions.Exit()
            return # Nem loopolja a függvényt, interakció kérése után kilép
    except ImportError:
            extensions.Error(1) # Bemeneti file hiba, nincs loop
    print("Kilépéshez üssön Entert üres sorban!")
    try:
        which = input()
        if which == "":
            return
        which = int(which) # ValueErrort dob, ha nem szám
        if Exisingtables(which) == False: # Ha nincs ilyen sorszámú asztal
            extensions.Error(3) # Értelmetlen bemenet
            extensions.Clear()
            Table_opening() #loop
        for b in templist:
            if b.number == which: # Ha elértük a kívánt sorszámú asztalt
                if b.reserved == "s":
                    b.reserved = "f"
                    Tabsave(templist) # Foglaltra állítjuk, és felülírjuk a fájlt
                    print("Az asztalfoglalás sikeres!")
                    extensions.Exit() 
                elif b.reserved == "f":
                    print("Ez az asztal már foglalt!") 
                    extensions.Exit() 
                    extensions.Clear()
                    Table_opening()           
    except ValueError:
        extensions.Error(3) # Értelmetlen bemenet
        extensions.Clear()
        Table_opening()

def Table_drawing(): # Asztalok grafikus megjelenítése
    extensions.turtle_reopen() # Hogy akárhányszor hívható legyen a függvény, mindig bezárja a teknőcöt
    templist = TableOpener() # Eltárolja az asztalokat
    #ablak
    window = turtle.Screen()
    window.setup(1240, 720)
    window.bgcolor("black")
    window.title("Az asztalok elhelyezkedése")
    #ceruza
    turtle.speed(0)
    turtle.color("black")
    turtle.penup()        
    #rajzolás
    if len(templist) < 1: # Ha a fájl megvan, de nincsenek benne asztalok
        turtle.goto(0, 0)
        turtle.color("red")
        turtle.write("Nincsenek asztalok!", move=False, align="left", font=("Arial", 40, "bold"))
    try:
        for a in templist:
            turtle.goto(a.x-50, a.y+50) # Az asztal bal felső sarokba megy
            deskcolor="blue" # Alapérték
            if a.reserved == "s":
                deskcolor = "green"
            elif a.reserved == "f":
                deskcolor="red" # Ha szabad az asztal, zöld, ha foglalt, piros
            else:
                raise ImportError            
            turtle.color(deskcolor)
            turtle.fillcolor(deskcolor)
            turtle.pendown()
            turtle.begin_fill()
            for _ in range(4):
                turtle.forward(100)
                turtle.right(90)
            turtle.end_fill() # Téglalap rajzolása, kitöltése színnel
            turtle.penup()
            turtle.goto(a.x-15, a.y-30) # Belemászik a téglalapba
            turtle.color("blue")
            turtle.pendown()
            turtle.write(a.places, move=False, align="left", font=("Arial", 40, "bold")) # Beleírja a férőhelyeket
            turtle.color("black")
            turtle.penup()
        turtle.goto(620, 360) # Feketére (mint a háttérszín) vált, és kimászik a sarokba, hogy ne látszódjon
        window.mainloop() # Nem záródik be az ablak
    except ImportError:
        extensions.Error(1) # Bemeneti file hiba

def Table_modify():
    templist = TableOpener()  # Eltárolja az asztalokat
    print("Asztalok módosítása\nMit kíván tenni?\n")
    print("Helyek számának módosítása:          1")
    print("Szabad/foglalt állapot módosítása:   2")
    print("Hely módosítása:                     3")
    print("Asztal hozzáadása:                   4")
    print("Asztal törlése:                      5")
    try:
        choose = int(input()) # ValueErrort dob, ha nem szám
        if choose > 5 or choose < 1:
            raise ValueError # Ha túl nagy vagy túl nagy számot adnak meg a kismenüben
        if choose != 4: # Ha nem újat hozzáadni akarnak
            print("Az asztalok:")
            for a in templist:
                print(str(a)) # Kiírjuk az összes létező asztalt, hogy könnyebb legyen választani
            tablenumber = int(input("Melyik asztalt kívánja módosítani? "))
            if Exisingtables(tablenumber) == False: # Ha nincs ilyen sorszámú asztal
                extensions.Error(3) # Nem létező opció
                extensions.Clear()
                Table_modify()
            Modify(tablenumber, choose)
        else:       
            Modify(0, choose) # Ha új asztalt akarnak hozzáadni 
    except ValueError:
        extensions.Error(4) # Nem létező opció
        extensions.Clear()
        Table_modify()

def Modify(desknumber, task):
    templist = TableOpener()  # Eltárolja az asztalokat
    if task == 4: # Új asztal létrehozása
            maxnum = 0
            for a in templist:
                    if a.number > maxnum:
                        maxnum = a.number
            newnumber = maxnum + 1 # Automatikusan generálja a sorszámot
            print("Az új asztal sorszáma automatikusan beállítva: {}".format(maxnum+1))
            try:
                newplaces = int(input("Adja meg az új asztal férőhelyeit: ")) # ValueErrort dob, ha nem szám
            except ValueError:
                extensions.Error(3) # Értelmetlen bemenet
                extensions.Clear()
                Table_modify() # Loop
            newreserved = "s" # Beállítja az asztalt szabadra
            print("Az új asztal szabadra állítva!")
            try:
                newx = int(input("Adja meg az új asztal X koordinátáját: "))
                newy = int(input("Adja meg az új asztal Y koordinátáját: ")) 
                for b in templist:
                    if int(b.x) == int(newx) or int(b.y) == int(newy):
                        raise IndexError # Volt már ilyen koordinátájú asztal
            except ValueError:
                extensions.Error(3) # Értelmetlen bemenet
                extensions.Clear()
                Table_modify() # Loop
            except IndexError:
                extensions.Error(5) # Volt már ilyen
                extensions.Clear()
                Table_modify()
            templist.append(Table(newnumber, newplaces, newreserved, newx, newy))  
    elif task == 1: # Helyek számának módosítása
        mod = input("Mire kívánja módosítani: ")
        for c in templist:
            if c.number == desknumber: # Ha elértük a kívánt sorszámú asztalt
                try:
                    int(mod)
                    for d in templist:
                        if d.number == mod:
                            raise ValueError
                    c.places = mod
                except ValueError:
                    extensions.Error(3) # Értelmetlen bemenet  
                    extensions.Clear()
                    Table_modify() 
    elif task == 2: # Szabad / foglalt módodítás
        for x in templist:
            if x.number == desknumber: # Ha elértük a kívánt sorszámú asztalt
                try:
                    if x.reserved == "f":
                        x.reserved = "s"
                    elif x.reserved == "s":
                        x.reserved = "f" # Invertáljuk a foglaltságot
                    else:
                        raise ValueError
                except Exception:
                    extensions.Error(1) # Bemeneti file hiba  
                    # Nem loopolja magát, hogy hibás file esetén ne próbálja meg újra és újra                 
    elif task == 3: # Koordináták módosítása
        for e in templist:
            if e.number == desknumber:
                newx = input("Új X: ")
                newy = input("Új Y: ")
                try:
                    int(newy)
                    int(newy) # ValueErrort dobnak, ha nem szám                    
                    for f in templist:
                        if int(f.x) == int(newx) or int(f.y) == int(newy):
                            raise IndexError # Volt már ilyen koordinátájú asztal
                    e.x=newx
                    e.y=newy
                except ValueError:
                    extensions.Error(3) # Értelmetlen bemenet
                    extensions.Clear()
                    Table_modify()   
                except IndexError:
                    extensions.Error(5) # Volt már ilyen
                    extensions.Clear()
                    Table_modify()
    elif task == 5: # Törlés
        for g in templist:
            if g.number == desknumber:
                templist.remove(g)
                # Nincs hiba, nincs loop
    Tabsave(templist) # Kiírjuk a módosításokat, a templistet a fájlba, felülírva azt
    print("Az értelmezett módosítások sikeresen végre lettek hajtva!")
    extensions.Exit() # Várunk interakcióra a kilépéshez