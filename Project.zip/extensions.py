import os
import turtle

def Error(id): # Hibák kezelése
    errorlist = [
        "Bemeneti fájl hibás!",
        "Bemeneti fájl nem létezik!",
        "A bemenet nem értelmezhető!",
        "Kérem, a megadott opciókból válasszon!",
        "Ilyen opció már szerepelt korábban!"
    ]
    errormsg=errorlist[id - 1]
    print(errormsg)
    Exit()

def Clear(): # Konzol tisztítása
    os.system('cls')

def Exit(): # Várunk interakcióra a kilépéshez
    input("Nyomjon le egy gombot a folytatáshoz...")

def turtle_reopen(): # Teknőccel hogy akárhányszor lehessen rajzolni
    turtle.Turtle._screen = None
    turtle.TurtleScreen._RUNNING = True