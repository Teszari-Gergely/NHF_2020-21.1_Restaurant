import desks
import os
import extensions

class Menu: # Osztály az étlap részére
    def __init__(self, number, food, price):
        try:
            if type(number) is int and type(food) is str and type(price) is int:
                self.number = number
                self.food = food
                self.price = price
            else:
                raise ValueError
        except ValueError:
            extensions.Error(1) # Bemeneti file hiba
    def __str__(self): # Ez a képernyőre kiíraráshoz kell, pl: 0: Alma, 200
        return "{}: {}, {}".format(self.number, self.food, self.price)
    def save(self): # Ez a fájlba íratáshoz kell, pl: 0;Alma;200
        return("{};{};{}\n").format(self.number, self.food, self.price)

def MenuOpener(): # Az étlapot tartalmaz txt fájl megnyitása
    foodlist = []
    try:
        with open("menu.txt", "rt", encoding="utf-8") as b:
            for oneline in b:
                oneline = oneline.strip()
                if oneline != "":
                    parts = oneline.split(";")
                    try:
                        foodlist.append(Menu(int(parts[0]), parts[1], int(parts[2])))
                    except ValueError:
                        extensions.Error(1) # Bemeneti file hiba
        return foodlist
    except FileNotFoundError:
        extensions.Error(2)

def Existingfoods(item): # Kap egy sorszámot, és ha van olyan sorszámú étel, akkor True-val tér vissza, külonen False-al
    lis = MenuOpener()
    for a in lis:
        if item == a.number:
            return True
    return False

def Order(): # Rendelés leadó függvény
    templist = MenuOpener() # Eltárolja az ételeket
    tablist = desks.TableOpener() # Eltárolja az asztalokat
    orders = [] # Ebben lesznek a rendelések
    print("Rendelés leadás")
    try:
        choose = int(input("Adja meg az asztal számát: "))
        desknumber = str(choose) + ".txt" # Ez az asztal számát és a kiterjesztést tárolja
        if desks.Exisingtables(choose) == False: # Ha nem létezik olyan sorszámú asztal
            extensions.Error(3) # Értelmetlen bemenet
            extensions.Clear()
            Order()
    except ValueError:
        extensions.Error(3) # Értelmetlen bemenet
        extensions.Clear()
        Order()
    try:
        for a in tablist:
            if a.number == choose: # Ha megvan a keresett sorszámú asztal
                if a.reserved == "s":
                    a.reserved = "f"
                    desks.Tabsave(tablist) # Lefoglalja az asztalt, és a módosítással együtt kiírja a fájlba az összes asztalt, felülírva az eddigi állapotot             
                    print("Az asztal foglaltra állítva!")
                    break
                else: # Ha már foglalt az asztal, beolvassuk a rendeléseiket, ha van
                    try:
                        with open(desknumber, "rt", encoding="utf-8") as d: # sorszám.txt-t egpróáljuk megnyitni
                            try:
                                for oneline in d: # Ha sikerült, akkor sorokat kivesszük...
                                    oneline = oneline.strip()
                                    if oneline != "":
                                        parts = oneline.split(";") # ... akkor szétdaraboljuk a pontosvesszőnél (Így legalább biztos jó az adatsor) ...
                                        orders.append(str(parts[0] + ";" + parts[1])) # ... és hozzáfüzzük a rendeléseket tartalmazó listához
                            except Exception:
                                extensions.Error(1) # Bemeneti file hiba, nincs loop
                    except FileNotFoundError: # Ha nincs számla még, de foglalt az asztal
                        pass 
    except ValueError:
        extensions.Error(3) # Értelmetlen bemenet
    for b in templist: # Kiírjuk az ételeket, sztringként
        print(str(b))
    print("Írja be az étel sorszámát, és üssön Entert!\nHa végzett, üres sorban üssön Entert!")
    while True:
        oneitem = input()
        if oneitem == "": # Üres sor jelzi a bemenet végét
            break
        try:
            oneitem = int(oneitem) # a sorszámot számmá próbáljuk konvertálni
        except ValueError:
            extensions.Error(3)  # Értelmetlen bemenet 
        if Existingfoods(oneitem) == False: # Ha nincs ilyen sorszámú étel
            extensions.Error(4) # Nem létező opció, nem lépünk ki, hanem hadd folytassák a bevitelt
        else:
            for c in templist: 
                if c.number == int(oneitem): # Különben végigmegyünk a listán, az adott sorszámú elemhez ha elérkeztünk...
                    cutted = str(str(c.food) + ";" + str(c.price)) # ... csak a nevét és az árát...
                    orders.append(cutted)
            print("A hozzáadás sikeres: {}".format(cutted)) # ... hozzáadjuk a rendelésekhez
    # ha a oneitem = "": számla file készítése
    with open(desknumber, "wt", encoding="utf-8") as d:
        for oneline in orders:
                if oneline != "":
                    d.write(oneline + "\n")
    print("A rendelések leadása sikeres!")
    extensions.Exit() # Várunk interakcióra a kilépéshez

def Receipt():
    print("Számla nyomtatása")
    print("Melyik asztal számláját kívánja nyomtatni?")
    print("A kilépéshez üssön Entert üres sorban!")
    try:
        choose = input()
        if choose == "":
            return
        choose = int(choose)
        table = str(choose) + ".txt" # Ismét fájlnév.txt-ként eltároljuk
        try:
            total = 0
            with open(table, "rt", encoding="utf-8") as d:                 
                try:
                    for oneline in d: # Végigmenyünk a rendelések listáján...
                        oneline = oneline.strip()
                        parts = oneline.split(";") # ... szétszedjük pontosvesszőnként...
                        print("{}\t{}".format(parts[0], parts[1])) # ... kiírjuk szép, szellős formátumban
                        total += int(parts[1]) # ... és az árat hozzáadjuk mindig a végösszeghez
                except Exception:
                    extensions.Error(1) # Bemeneti file hiba
            print("Végösszeg: ", total)
            payed = input("A fizetéshez írjon be egy X-et, kilépéshez bármi mást, majd üssön Entert!")
            if payed == "x":
                os.remove(table) # Törli a fájlt
                print("Fizetve!")
                tablist = desks.TableOpener() # Innentől állítja át az asztalt szabadra
                for a in tablist:
                    if a.number == choose: # Ha elérkeztünk a megfelelő sorszámú asztalhoz, megpróbáljuk szabadra állítani
                        if a.reserved == "f":
                            a.reserved = "s"
                            desks.Tabsave(tablist)                                                   
                        else:
                            print("Az asztal szabad volt, mégis volt hozzá rendelés") # Ha nem sikerült szabadra állítani
                            extensions.Error(1) # Bemeneti file hibás
                    else:
                        pass                            
                print("Az asztal szabadra állítva!")  
                extensions.Exit()              
        except FileNotFoundError:
            print("Ehhez az asztalhoz nincs leadva rendelés!") # Ha nem találtunk ilyen sorszámú fájlt, azaz asztalhoz leadott rendelést
            extensions.Exit()
            extensions.Clear()
            Receipt()
    except ValueError:
        extensions.Error(3) # Értelmetlen bemenet 
        extensions.Clear()
        Receipt()   

def Menu_modify():
    templist = MenuOpener() # Eltárolja az ételeket
    print("Menü módosítása\nMit kíván tenni?")
    print("Étel nevének módosítása: 1")
    print("Étel árának módosítása:  2")
    print("Étel hozzáadása:         3")
    print("Étel törlése:            4")       
    try:
        choose = int(input()) # ValueErrort dob, ha nem szám
        if choose > 4 or choose < 1: # Túl kicsi vagy túl nagy szám a kismenüben
            raise ValueError
        if choose != 3: # Ha nem újat akarnak hozzáadni
            for a in templist: # Kiírjuk az összes ételt
                print(str(a))
            calledfood = int(input("Melyik sorszámú elemet kívánja módosítani: ")) # ValueErrort dob, ha nem szám
            if Existingfoods(calledfood) == False: # Ha nincs ilyen sorszámú étel
                extensions.Error(3) # Értelmetlen bemenet
                extensions.Clear()
                Menu_modify()
            else:
                for b in templist:
                    if b.number == calledfood:
                        Modify(b.food, choose)
        else:
            Modify("nothing", choose) # Ha újat akarnak hozzáadni
    except ValueError:
        extensions.Error(3) # Értelmetlen bemenet
        extensions.Clear()
        Menu_modify()

def Modify(call, task):
    templist = MenuOpener() # Eltárolja az ételeket
    if task == 3: # Ha új ételt akarnak definiálni
        try:
            maxnum = 0 # Innentől generálja automatikusan a sorszámot
            for a in templist:
                if a.number > maxnum:
                    maxnum = a.number
            maxnum += 1 # Mivel nullától számol a ciklus, nullás sorszámú asztal meg nincsen
            print("Az új étel sorszáma automatikusan beállítva: ", maxnum)
            newfood = input("Adja meg az új étel nevét: ")            
            for b in templist:
                if b.food == newfood: # Ha szerepelt már korábban ilyen névvel étel
                    raise ValueError
            newprice = int(input("Adja meg az új étel árát: ")) # ValueErrort dob, ha nem szám
            templist.append(Menu(maxnum, newfood, newprice))
        except ValueError:
            extensions.Error(3) # Értelmetlen bemenet  
            extensions.Clear()
            Menu_modify()   
    # Ha nem újat definiálnak
    for c in templist:
        if task == 1 or task == 2: # Ha nem törölni kell
            if c.food == call:
                mod = input("Mire kívánja módosítani: ")
                if task == 1: # Étel nevének módosítása
                    try:
                        for d in templist:
                            if d.food == mod: # Ha volt már ilyen névvel étel
                                raise ValueError
                            else:
                                pass                            
                        c.food = mod
                    except ValueError:
                        extensions.Error(3) # Értelmetlen bemenet
                        extensions.Clear()
                        Menu_modify()
                elif task == 2: # Étel árának módosítása
                    try:
                        mod = int(mod)
                        c.price = mod
                    except ValueError: # Ha nem számot adtak meg
                        extensions.Error(3) # Értelmetlen bemenet
                        extensions.Clear()
                        Menu_modify()
        elif task == 4:
            if c.food == call:
                templist.remove(c) # Listaelem törlése
                # Nincs hiba, nics loop
    with open("menu.txt", "wt", encoding="utf-8") as e: # Módosítások kiírása fájlba, felülírva az addigiakat
        for f in templist:
                e.write(f.save())
    print("Az értelmezett módosítások sikeresen végre lettek hajtva!")
    extensions.Exit() # Várunk interakcióra a kilépéshez